% Monte Carlo Simulation

% Task 1 : Using for loop to compute pi within a fixed number 
% of deviations

% Using helper function 'estimate' for this task: defined in 
% 'estimate.m' file

clear; clc; close all; % Clearing everything first

% Choosing range of exponents for 2^k points: 1 million points
k = 10:20;
N = 2.^k;
% Initializing variables
piestimate = zeros(size(N)); % Estimate of pi
elapsed_time = zeros(size(N)); % Amount of time elapsed in seconds
pierror = zeros(size(N)); % Error

% Constructing for loop to compute pi within fixed number of deviations
for idx = 1:length(k)
    n = N(idx); % Number of points
    tic; % Timing the simulation
    piestimate(idx) = estimate(n); % Calling helper function 'estimate'
    elapsed_time(idx) = toc; % Measuring time elapsed
    pierror(idx) = abs(piestimate(idx) - pi); % Calculating precision
end

% Plotting pi estimate and deviation from the true value
% vs. number of points
figure(1)
yyaxis left
semilogx(N, piestimate, 'm-o') % Pi estimate
ylabel('Estimated \pi')

yyaxis right
semilogx(N, pierror, 'b-s') % Error
ylabel('Error')

xlabel('Number of Points')
title('Estimation of \pi and Error vs Number of Points')
legend('Estimate of \pi','Error','Location','northeast')
grid on

% Plotting precision vs. computational cost
figure(2)
loglog(elapsed_time, pierror, 'r-o')
xlabel('Execution time (seconds)')
ylabel('Precision')
title('Precision vs Computational Cost')
grid on


% Task 2: Using a while loop to compute pi to a specified 
% level of precision and recording the number of iterations 
% required to achieve each level of precision

% Using helper function 'estimate2', which can be found in the
% file 'estimate2.m'


% Initializing variables
piest = zeros(1,3); % Pi estimate
n = zeros(1,3); % Number of points
time = zeros(1,3); % Time elapsed


for i = 1:3 % Looping over 2-4 significant figures
    sig = i + 1; % 2 - 4 significant figures
    tic; % Timing the simulation
    % Calling helper function 'estimate2' to estimate pi to 
    % specificed precision
    [piest(sig), n(sig)] = estimate2(sig);
    time(sig) = toc; % Recording time elapsed
end

% Displaying results in a table

disp(table((2:4)', piest(2:4)', n(2:4)', time(2:4)', ...
    'VariableNames', {'Sig Figs','Pi Estimate','Iterations','Time'}));


 
