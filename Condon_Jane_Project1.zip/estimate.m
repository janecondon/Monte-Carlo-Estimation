function [piestimate] = estimate(n)
% This function uses a for loop to  estimate pi using a fixed number of
%  points, using the Monte Carlo simulation.
% The function takes total number of points as input and returns the
% estimate of pi

% Initializing variables
ninside = 0; % Number of points inside the circle
piestimate = 0; % Estimate of pi

% Monte Carlo Simulation
for i = 1:n
    x = -1 + 2*rand(); % Generating x value
    y = -1 + 2*rand(); % Generating y value
    if (x^2 + y^2) <= 1 % Checking for points inside the circle
        ninside = ninside + 1; % Adding up points inside the circle
    end
end
piestimate = 4*(ninside./n); % Calculating estimate of pi
    
end
