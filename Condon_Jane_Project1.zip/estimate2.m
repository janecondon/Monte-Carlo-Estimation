function [piest, n] = estimate2(sig_figs)
% This function estimates pi to a specified level of precision
% (desired significant figures) without using the true value of pi, 
% using the Monte Carlo simulation.
% This function returns an estimate of pi.

% Initializing variables
piest = 0; % Current estimate of pi
ninside = 0; % Number of points inside the circle
n = 0; % Number of points

% Creating buffer to store the last few estimates of pi so that
% we are requiring multiple consecutive estimates to match: makes 
% the estimate more stable and accurate.

buffersize = 10; % Number of consecutive estimates to check
buffer = zeros(1, buffersize); % Storing last 10 estimates

% Monte Carlo Simulation
while true 
    n = n + 1; % Adding 1 to number of points
    x = -1 + 2*rand(); % Generating random x value
    y = -1 + 2*rand(); % Generating random y value
    if (x^2 + y^2) <= 1 % Checking if point lies inside unit circle
        ninside = ninside + 1; 
    end
    
    piest = 4 * ninside / n; % Updating current estimate of pi
    buffer = [buffer(2:end), piest]; % Updating buffer
    
    % Checking if values in buffer match the desired significant
    % figures
        if n >= buffersize
        rounded = round(buffer, sig_figs, 'significant');
        if length(unique(rounded)) == 1
            break % Stop when desired precision is achieved
        end
    end
end
end
