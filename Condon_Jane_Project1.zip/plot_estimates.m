function piest = plot_estimates(sig_figs)
% This functions estimates pi to a specified number of significant
%  figures using the Monte Carlo method and plots the random points.
%  This function takes a user-specified number of
% significant figures ('sig figs') and returns the final 
% estimate of pi.

% Initializing variables
piest = 0; % Current estimate of pi
ninside = 0; % Number of points inside the circle
n = 0; % Total number of points

% Creating buffer to store the last few estimates of pi so that
% we are requiring multiple consecutive estimates to match: makes 
% the estimate more stable and accurate.

buffer_size = 10; % Number of consecutive estimates to check
buffer = zeros(1, buffer_size); % Storing last 10 estimates
min_iter = 50; % Minimum iterations

% Setting up the plot
figure;
hold on;
axis equal;
xlim([-1 1]); % Holding x-values between -1 and 1
ylim([-1 1]); % Holding y-values between -1 and 1
xlabel('X'); % Labeling the x-axis as 'X'
ylabel('Y'); % Labeling the y-axis as 'Y'
title('Monte Carlo Estimation of \pi'); % Creating a title for the plot

% Plotting the unit circle
theta = linspace(0,2*pi,100);
plot(cos(theta), sin(theta), 'k-', 'LineWidth', 2);

% Monte Carlo Simulation
while true
    n = n + 1; % Adding 1 to number of points
    x = -1 + 2*rand(); % Generating random x value
    y = -1 + 2*rand(); % Generating random y value
    if x^2 + y^2 <= 1 % Checking if the point lies inside the unit circle
        ninside = ninside + 1;
        plot(x, y, 'b.'); % Inside the circle: plot a blue point
    else
        plot(x, y, 'r.'); % Outside the circle: plot a red point
    end
    
    piest = 4 * ninside / n; % Updating estimate
    
    % Updating buffer
    buffer = [buffer(2:end), piest];
    
    % Checking if the estimate has stabilized
    if n >= max(min_iter, buffer_size)
        rounded = round(buffer, sig_figs, 'significant');
        if length(unique(rounded)) == 1
            break
        end
    end
end

% Displaying final estimate
fprintf('Estimated value of pi to %d significant figures: %.*f\n', ...
        sig_figs, sig_figs, piest);

% Printing value on the plot
text(0, -1.1, sprintf('\\pi ≈ %.*f', sig_figs, piest), ...
    'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');

hold off;

end
